import './App.css';
import CommentHook from './CommentHook';
import Comment2Hook from './Comment2Hook';
import PlaceholderPostHook from './PlaceholderPostHook';

function App() {
  return (
    <>
      <PlaceholderPostHook/>
      <CommentHook/>
      <Comment2Hook/>
    </>
  );
}

export default App;
