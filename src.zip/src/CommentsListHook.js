function CommentsListHook(props) {
    console.log(props)
    return (
        <>
            {props.data.map((item, index) => 
                    <section key={item.id}>
                        <p><b>{index + 1}. {item.email}</b></p>
                        <p>{item.body}</p>
                    </section>
                 )}
        </>
    )
}

export default CommentsListHook;